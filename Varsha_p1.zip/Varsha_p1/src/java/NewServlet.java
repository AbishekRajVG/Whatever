/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author TJRAJ
 */
@WebServlet(urlPatterns = {"/NewServlet"})
public class NewServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        int correct =0;
       if((request.getParameter("question 1")).equals("a")){
            correct++;}
       if((request.getParameter("question 2")).equals("a")){
            correct++;}
       if((request.getParameter("question 3")).equals("b")){
            correct++;}
       
 
    int range = 0;
      if(correct < 1)
         {
           range=2;
         }
     if (correct>0 && correct<3)
        {
         range=1;
        }
     if(correct>2)
        {  
         range=0;
        }


    String[] messages = {"wow!!! EXCELLENT", "THAT'S BETTER", "OOPS!! U NEED TO WORK MORE"};
    String[] pictures = {"C:\\Users\\TJRAJ\\Desktop\\gif pro\\clap.gif","C:\\Users\\TJRAJ\\Desktop\\gif pro\\meh.gif","C:\\Users\\TJRAJ\\Desktop\\gif pro\\worst.gif"};
    
    out.println("<h1>you got "+ correct +" Correct!!!");
    out.print("<h2>"+ messages[range] +"</h2>");
    out.print("<img src ="+pictures[range]+">");
}
       }