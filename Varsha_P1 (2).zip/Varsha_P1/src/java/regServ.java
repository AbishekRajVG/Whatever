/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author TJRaj
 */
@WebServlet(urlPatterns = {"/regServ"})
public class regServ extends HttpServlet {

   
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        String un = request.getParameter("uname");
        String ps = request.getParameter("pwd");
        String ps2 = request.getParameter("pwd2");
        String def="Reg.html";
        if(!ps.equals(ps2)){
            out.println("<a href =" + def + ">Passwords Dont Match, Retry </a>");}
        else{
          
            String abc ="Login.html";
            try{
              
                 Class.forName("org.h2.Driver");
            Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
            Statement stmt = con.createStatement();
            String sql="insert into TN values ('" + un + "','" + ps + "',0)";
               stmt.execute(sql);   
              
               stmt.close();con.close();
               
                
                out.println("<html><body bgcolor=\"powderblue\"><center><h1>Registeration Success</h1>");
                out.println("<h2>Welcome " + un + "</h2>");
                out.println("<a href="+abc+">Continue to Login Page</a></center></body></html>");
                
            }catch(Exception e){e.printStackTrace();}
            
        }
    }
    }

    


