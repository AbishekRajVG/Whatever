/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author TJRaj
 */
@WebServlet(urlPatterns = {"/LoginValidate"})
public class LoginValidate extends HttpServlet {

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            PrintWriter out = response.getWriter();
            HttpSession session = request.getSession(true);
        String un = request.getParameter("uname");
        String ps = request.getParameter("pwd");
        session.setAttribute("username",un);
             
        try {
             Connection con = null;Statement stmt = null;ResultSet rs= null;    
            Class.forName("org.h2.Driver");
            con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
            stmt = con.createStatement();
            String sql="select * from TN";
            rs = stmt.executeQuery(sql);
                    String abc = "quiz.jsp";
                    
                while(rs.next()){
                    if(un.equals(rs.getString(1)) && ps.equals(rs.getString(2)))
                    {   out.println("<html><body bgcolor=\"lightyellow\"><center><h1>Login Success</h1>");
                        out.println("<h2>Welcome back..." + rs.getString(1) + "</h2>");                      
                        session.setAttribute("user", un);
                        out.println("<a href="+abc +">Continue to Quiz...</a></center></body></html>");
                        break;
                    }
                        
                }
       
        } 
        catch (Exception ex) {
           ex.printStackTrace();
        }
        
 }}
